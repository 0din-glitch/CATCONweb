/**
 * v0 by Vercel.
 * @see https://v0.dev/t/410K0voR4dy
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import Link from "next/link"
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuItem } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

export default function Component() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background dark:bg-[#1a1b1e]">
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-b-[#2c2d30] bg-background dark:bg-[#1a1b1e] px-4 sm:px-6">
        <Link href="#" className="flex items-center gap-2" prefetch={false}>
          <MountainIcon className="h-6 w-6 text-primary dark:text-primary-foreground" />
          <span className="text-lg font-semibold text-primary dark:text-primary-foreground">Acme SaaS</span>
        </Link>
        <nav className="flex items-center gap-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full ring-2 ring-primary dark:ring-primary-foreground"
              >
                <img
                  src="/placeholder.svg"
                  width={36}
                  height={36}
                  alt="Avatar"
                  className="rounded-full"
                  style={{ aspectRatio: "36/36", objectFit: "cover" }}
                />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              className="bg-background dark:bg-[#1a1b1e] ring-2 ring-primary dark:ring-primary-foreground"
            >
              <DropdownMenuLabel className="text-primary dark:text-primary-foreground">John Doe</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="hover:bg-muted dark:hover:bg-[#2c2d30]">Profile</DropdownMenuItem>
              <DropdownMenuItem className="hover:bg-muted dark:hover:bg-[#2c2d30]">Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="hover:bg-muted dark:hover:bg-[#2c2d30]">Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
      </header>
      <div className="flex flex-1">
        <aside className="hidden w-16 flex-col border-r border-r-[#2c2d30] bg-background dark:bg-[#1a1b1e] p-4 sm:flex">
          <nav className="flex flex-col items-center gap-4">
            <TooltipProvider>
              <Link
                href="#"
                className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground transition-colors hover:bg-primary/90 ring-2 ring-primary dark:ring-primary-foreground"
                prefetch={false}
              >
                <MountainIcon className="h-5 w-5" />
              </Link>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link
                    href="#"
                    className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted dark:hover:bg-[#2c2d30] ring-2 ring-primary dark:ring-primary-foreground"
                    prefetch={false}
                  >
                    <HomeIcon className="h-5 w-5" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent
                  side="right"
                  className="bg-background dark:bg-[#1a1b1e] text-primary dark:text-primary-foreground"
                >
                  Dashboard
                </TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link
                    href="#"
                    className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted dark:hover:bg-[#2c2d30] ring-2 ring-primary dark:ring-primary-foreground"
                    prefetch={false}
                  >
                    <BarChartIcon className="h-5 w-5" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent
                  side="right"
                  className="bg-background dark:bg-[#1a1b1e] text-primary dark:text-primary-foreground"
                >
                  Analytics
                </TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link
                    href="#"
                    className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted dark:hover:bg-[#2c2d30] ring-2 ring-primary dark:ring-primary-foreground"
                    prefetch={false}
                  >
                    <UsersIcon className="h-5 w-5" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent
                  side="right"
                  className="bg-background dark:bg-[#1a1b1e] text-primary dark:text-primary-foreground"
                >
                  Customers
                </TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link
                    href="#"
                    className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted dark:hover:bg-[#2c2d30] ring-2 ring-primary dark:ring-primary-foreground"
                    prefetch={false}
                  >
                    <PackageIcon className="h-5 w-5" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent
                  side="right"
                  className="bg-background dark:bg-[#1a1b1e] text-primary dark:text-primary-foreground"
                >
                  Products
                </TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link
                    href="#"
                    className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted dark:hover:bg-[#2c2d30] ring-2 ring-primary dark:ring-primary-foreground"
                    prefetch={false}
                  >
                    <SettingsIcon className="h-5 w-5" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent
                  side="right"
                  className="bg-background dark:bg-[#1a1b1e] text-primary dark:text-primary-foreground"
                >
                  Settings
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </nav>
        </aside>
        <div className="flex flex-1 flex-col">
          <main className="flex-1 p-4 sm:p-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              <Card className="ring-2 ring-primary dark:ring-primary-foreground">
                <CardHeader className="flex items-center justify-between">
                  <CardTitle className="text-primary dark:text-primary-foreground">Total Revenue</CardTitle>
                  <DollarSignIcon className="h-5 w-5 text-muted-foreground dark:text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-primary dark:text-primary-foreground">$45,231.89</div>
                  <p className="text-sm text-muted-foreground dark:text-muted-foreground">+20.1% from last month</p>
                </CardContent>
              </Card>
              <Card className="ring-2 ring-primary dark:ring-primary-foreground">
                <CardHeader className="flex items-center justify-between">
                  <CardTitle className="text-primary dark:text-primary-foreground">Subscriptions</CardTitle>
                  <UsersIcon className="h-5 w-5 text-muted-foreground dark:text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-primary dark:text-primary-foreground">+2,350</div>
                  <p className="text-sm text-muted-foreground dark:text-muted-foreground">+180.1% from last month</p>
                </CardContent>
              </Card>
              <Card className="ring-2 ring-primary dark:ring-primary-foreground">
                <CardHeader className="flex items-center justify-between">
                  <CardTitle className="text-primary dark:text-primary-foreground">Sales</CardTitle>
                  <CreditCardIcon className="h-5 w-5 text-muted-foreground dark:text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-primary dark:text-primary-foreground">+12,234</div>
                  <p className="text-sm text-muted-foreground dark:text-muted-foreground">+19% from last month</p>
                </CardContent>
              </Card>
              <Card className="ring-2 ring-primary dark:ring-primary-foreground">
                <CardHeader className="flex items-center justify-between">
                  <CardTitle className="text-primary dark:text-primary-foreground">Active Now</CardTitle>
                  <ActivityIcon className="h-5 w-5 text-muted-foreground dark:text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-primary dark:text-primary-foreground">+573</div>
                  <p className="text-sm text-muted-foreground dark:text-muted-foreground">+201 since last hour</p>
                </CardContent>
              </Card>
              <Card className="col-span-1 sm:col-span-2 lg:col-span-3 ring-2 ring-primary dark:ring-primary-foreground">
                <CardHeader>
                  <CardTitle className="text-primary dark:text-primary-foreground">Recent Orders</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-primary dark:text-primary-foreground">Invoice</TableHead>
                        <TableHead className="text-primary dark:text-primary-foreground">Status</TableHead>
                        <TableHead className="text-primary dark:text-primary-foreground">Method</TableHead>
                        <TableHead className="text-right text-primary dark:text-primary-foreground">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium text-primary dark:text-primary-foreground">INV001</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-primary dark:text-primary-foreground">
                            Paid
                          </Badge>
                        </TableCell>
                        <TableCell className="text-primary dark:text-primary-foreground">Credit Card</TableCell>
                        <TableCell className="text-right text-primary dark:text-primary-foreground">$250.00</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium text-primary dark:text-primary-foreground">INV002</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-primary dark:text-primary-foreground">
                            Pending
                          </Badge>
                        </TableCell>
                        <TableCell className="text-primary dark:text-primary-foreground">PayPal</TableCell>
                        <TableCell className="text-right text-primary dark:text-primary-foreground">$150.00</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium text-primary dark:text-primary-foreground">INV003</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-primary dark:text-primary-foreground">
                            Unpaid
                          </Badge>
                        </TableCell>
                        <TableCell className="text-primary dark:text-primary-foreground">Bank Transfer</TableCell>
                        <TableCell className="text-right text-primary dark:text-primary-foreground">$350.00</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium text-primary dark:text-primary-foreground">INV004</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-primary dark:text-primary-foreground">
                            Paid
                          </Badge>
                        </TableCell>
                        <TableCell className="text-primary dark:text-primary-foreground">Credit Card</TableCell>
                        <TableCell className="text-right text-primary dark:text-primary-foreground">$450.00</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium text-primary dark:text-primary-foreground">INV005</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-primary dark:text-primary-foreground">
                            Paid
                          </Badge>
                        </TableCell>
                        <TableCell className="text-primary dark:text-primary-foreground">PayPal</TableCell>
                        <TableCell className="text-right text-primary dark:text-primary-foreground">$550.00</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}

function ActivityIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" />
    </svg>
  )
}


function BarChartIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="12" x2="12" y1="20" y2="10" />
      <line x1="18" x2="18" y1="20" y2="4" />
      <line x1="6" x2="6" y1="20" y2="16" />
    </svg>
  )
}


function CreditCardIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="14" x="2" y="5" rx="2" />
      <line x1="2" x2="22" y1="10" y2="10" />
    </svg>
  )
}


function DollarSignIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="12" x2="12" y1="2" y2="22" />
      <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
    </svg>
  )
}


function HomeIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}


function MountainIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m8 3 4 8 5-5 5 15H2L8 3z" />
    </svg>
  )
}


function PackageIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m7.5 4.27 9 5.15" />
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </svg>
  )
}


function SettingsIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}


function UsersIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  )
}